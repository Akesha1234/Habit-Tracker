package com.example.myapplication.model

class Habit(val name: String, val time: Long) {
}